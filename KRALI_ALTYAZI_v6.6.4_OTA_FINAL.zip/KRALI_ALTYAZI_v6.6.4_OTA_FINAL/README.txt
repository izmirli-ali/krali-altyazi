KRALI ALTYAZI v6.6.4 OTA FINAL
- GÖRÜNÜM ana dört satırı tekrar çalıştırmalarda kontrolleri silmeyen idempotent authoritative DOM container olarak kurulur.
- Input ID'leri taşınır; mevcut renderer/event bağlantıları korunur.
- Ana satırlarda slider yoktur.
- GELİŞMİŞ alanına dokunulmaz.
- Updater disabled manifest durumunda artık 'Güncel' mesajına geçer.
- v6.6.3: Başlangıçtaki eski presetler, Leading/Tracking ve manuel bölme kilidi kaynak DOM'dan kaldırıldı.
- v6.6.4: OTA manifest ve ZIP isteklerine cache-busting eklendi.
- OTA updater version: 6.6.4.
