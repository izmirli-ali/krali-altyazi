/* KRALI Silence Cut host module.  It never operates on the source sequence. */
$._KRALI_SUB=$._KRALI_SUB||{};
$._KRALI_SUB.SilenceCut=$._KRALI_SUB.SilenceCut||{};
(function(M){
 var T=254016000000;
 function esc(v){return $._KRALI_SUB.esc(v)}
 function json(v){return JSON.stringify(v)}
 function active(){return app.project&&app.project.activeSequence}
 M.version=function(){return "1.0.0"};
 M.info=function(){try{var s=active();if(!s)return json({ok:false,message:"Aktif sequence yok."});return json({ok:true,name:String(s.name),duration:Number(s.end)/T})}catch(e){return json({ok:false,message:String(e)})}};
 M.audioTracks=function(){try{var s=active(),out=[];if(!s)throw Error("Aktif sequence yok.");for(var i=0;i<s.audioTracks.numTracks;i++){var n=0;try{n=s.audioTracks[i].clips.numItems}catch(_){}out.push({index:i,label:"A"+(i+1),clips:n})}return json({ok:true,tracks:out})}catch(e){return json({ok:false,message:String(e)})}};
 M.sourceMedia=function(trackIndex,selectedOnly){
  try{var s=active();if(!s)throw Error("Aktif sequence yok.");var ti=Number(trackIndex)||0;if(ti<0||ti>=s.audioTracks.numTracks)throw Error("Ses kanalı bulunamadı.");var tr=s.audioTracks[ti],out=[];
   for(var i=0;i<tr.clips.numItems;i++){var c=tr.clips[i],selected=false,p="";try{selected=!!c.isSelected()}catch(_){}if(selectedOnly&&!selected)continue;try{p=c.projectItem.getMediaPath()}catch(_){}if(!p)continue;var speed=1;try{speed=Math.abs(Number(c.getSpeed()))||1}catch(_){}out.push({name:String(c.name),path:String(p),start:Number(c.start.seconds),end:Number(c.end.seconds),inPoint:Number(c.inPoint.seconds),outPoint:Number(c.outPoint.seconds),speed:speed})}
   return json({ok:true,track:ti,clips:out});
  }catch(e){return json({ok:false,message:String(e)})}
 };
 M.makeSafeCopy=function(){
  try{var source=active();if(!source)throw Error("Aktif sequence yok.");var original=String(source.name);if(/^KRALI - SESSIZLIK - /i.test(original))return json({ok:false,message:"Zaten bir Sessizlik Kes kopyasındasın. Yeni analiz için kaynak sequence'e dön."});
   var used={},seqs=app.project.sequences;for(var i=0;i<seqs.numSequences;i++)used[String(seqs[i].name)]=1;
   var base="KRALI - SESSIZLIK - "+original,wanted=base,n=2;while(used[wanted]){wanted=base+" "+("0"+n).slice(-2);n++}
   if(!source.clone())throw Error("Sequence kopyalanamadı.");var cloned=active();if(!cloned||cloned===source)throw Error("Premiere güvenli kopyayı aktif sequence yapmadı; işlem durduruldu.");
   try{cloned.name=wanted}catch(e){throw Error("Kopya isimlendirilemedi; işlem durduruldu.")}
   if(String(cloned.name)!==wanted)throw Error("Kopya doğrulanamadı; işlem durduruldu.");
   return json({ok:true,source:original,clone:wanted});
  }catch(e){return json({ok:false,message:String(e)})}
 };
 M.applyCuts=function(cutsJSON,expectedClone){
  try{var s=active(),name=s&&String(s.name||"");if(!s)throw Error("Aktif sequence yok.");if(!/^KRALI - SESSIZLIK - /i.test(name)||name!==String(expectedClone))throw Error("Güvenlik kilidi: yalnızca bu işlem için oluşturulan KRALI Sessizlik kopyasında kesim uygulanabilir.");
   var cuts=JSON.parse(cutsJSON);if(!cuts||!cuts.length)throw Error("Uygulanacak kesim yok.");
   for(var order=0;order<cuts.length;order++){if(!(Number(cuts[order].end)>Number(cuts[order].start)))throw Error("Geçersiz kesim planı.")}
   app.enableQE();var q=qe.project.getActiveSequence();if(!q)throw Error("QE aktif sequence erişimi başarısız.");
   cuts.sort(function(a,b){return Number(b.start)-Number(a.start)});var before=Number(s.end)/T,applied=0,details=[];
   for(var ci=0;ci<cuts.length;ci++){
    var cut=cuts[ci],a=Number(cut.start),b=Number(cut.end),endNow=Number(s.end)/T,endCut=b>=endNow-.02;
    try{
     var ta=new Time();ta.seconds=a;s.setPlayerPosition(ta.ticks);var tcA=q.CTI.timecode,tcB=null;
     if(!endCut){var tb=new Time();tb.seconds=b;s.setPlayerPosition(tb.ticks);tcB=q.CTI.timecode}
     var i;for(i=0;i<q.numVideoTracks;i++){try{var vt=q.getVideoTrackAt(i);vt.razor(tcA);if(tcB)vt.razor(tcB)}catch(_){}}
     for(i=0;i<q.numAudioTracks;i++){try{var at=q.getAudioTrackAt(i);at.razor(tcA);if(tcB)at.razor(tcB)}catch(_){}}
     var victims=[];function collect(tracks){for(var x=0;x<tracks.numTracks;x++){var tr=tracks[x];for(var y=0;y<tr.clips.numItems;y++){var clip=tr.clips[y],st=Number(clip.start.seconds),en=Number(clip.end.seconds);if(st>=a-.003&&(endCut?en<=endNow+.01:en<=b+.003))victims.push(clip)}}}
     collect(s.videoTracks);collect(s.audioTracks);if(!victims.length){details.push({start:a,end:b,status:"skipped",reason:"Kesilecek parça bulunamadı"});continue}
     for(i=0;i<victims.length-1;i++){try{victims[i].remove(0,1)}catch(_){}}
     var ripple=false;try{victims[victims.length-1].remove(1,1);ripple=true}catch(e){try{victims[victims.length-1].remove(0,1)}catch(_){}}
     applied++;details.push({start:a,end:b,status:"applied",reason:ripple?"Ripple uygulandı":"Parça kaldırıldı"});
    }catch(e){details.push({start:a,end:b,status:"failed",reason:String(e)})}
   }
   var after=Number(s.end)/T;return json({ok:true,clone:name,applied:applied,failed:cuts.length-applied,planned:cuts.reduce(function(n,c){return n+Math.max(0,Number(c.end)-Number(c.start))},0),actualRemoved:Math.max(0,before-after),details:details});
  }catch(e){return json({ok:false,message:String(e)})}
 };
})( $._KRALI_SUB.SilenceCut );
