$._AUTOCUT = $._AUTOCUT || {};

$._AUTOCUT.hostVersion = function(){ return "3.2.0"; };
$._AUTOCUT.pingSequence = function(){
    try{
        if(!app.project || !app.project.activeSequence)return "ERR|Aktif sekans yok";
        return "OK|"+app.project.activeSequence.name;
    }catch(e){return "ERR|"+e.toString();}
};
$._AUTOCUT.makeBackup = function(){
    try{
        var seq=app.project.activeSequence;if(!seq)return "ERR|Aktif sekans yok";
        var original=String(seq.name).replace(/^KRALI\s*-\s*/i,"");
        var base="KRALI - "+original, wanted=base, n=2, used={};
        try{
            var ss=app.project.sequences;
            for(var i=0;i<ss.numSequences;i++)used[String(ss[i].name)]=true;
            while(used[wanted]){wanted=base+" "+("0"+n).slice(-2);n++;}
        }catch(_){}
        var ok=seq.clone();if(!ok)return "ERR|Sekans kopyalanamadı";
        var cloned=app.project.activeSequence;
        if(cloned){try{cloned.name=wanted;}catch(_){}}
        return "OK|"+wanted;
    }catch(e){return "ERR|"+e.toString();}
};


$._AUTOCUT.esc = function(s) {
    if (s === null || s === undefined) return "";
    return String(s).replace(/\\/g,"\\\\").replace(/"/g,'\\"').replace(/\r/g,"\\r").replace(/\n/g,"\\n");
};

$._AUTOCUT.devMode = function () {
    try { app.setExtensionPersistent("com.krali.cep.panel", 0); return "OK"; }
    catch(e) { return e.toString(); }
};

$._AUTOCUT.getSequenceInfo = function () {
    try {
        var s = app.project.activeSequence;
        if (!s) return '{"ok":false,"message":"Open a sequence first."}';
        var dur = 0;
        try { dur = Number(s.end) / 254016000000; } catch (_) {}
        return '{"ok":true,"name":"' + $._AUTOCUT.esc(s.name) + '","duration":' + dur + '}';
    } catch(e) {
        return '{"ok":false,"message":"' + $._AUTOCUT.esc(e.toString()) + '"}';
    }
};

$._AUTOCUT.getAudioTracks = function(){
    try{
        var seq=app.project.activeSequence;if(!seq)return '{"ok":false,"message":"Aktif sekans yok."}';
        var arr=[];
        for(var i=0;i<seq.audioTracks.numTracks;i++){
            var t=seq.audioTracks[i], count=0;try{count=t.clips.numItems}catch(_){}
            arr.push('{"index":'+i+',"label":"A'+(i+1)+'","clips":'+count+'}');
        }
        return '{"ok":true,"tracks":['+arr.join(",")+']}';
    }catch(e){return '{"ok":false,"message":"'+$._AUTOCUT.esc(e.toString())+'"}';}
};

// Markers are editorial intent.  The panel uses them as protected zones and
// never sends those candidates to the destructive cut pass.
$._AUTOCUT.getMarkers = function(){
    try{
        var seq=app.project.activeSequence;if(!seq)return '{"ok":false,"message":"Aktif sekans yok."}';
        var out=[],m=seq.markers;
        while(m){
            var start=0,end=0;try{start=Number(m.start.seconds)}catch(_){}try{end=Number(m.end.seconds)}catch(_){end=start}
            out.push('{"start":'+start+',"end":'+Math.max(start,end)+'}');
            try{m=m.getNextMarker(m.start)}catch(_){m=null}
        }
        return '{"ok":true,"markers":['+out.join(',')+']}';
    }catch(e){return '{"ok":false,"message":"'+$._AUTOCUT.esc(e.toString())+'"}';}
};

$._AUTOCUT.getSourceMedia = function (trackIndex, selectedOnly) {
    try {
        var seq=app.project.activeSequence;
        if (!seq) return '{"ok":false,"message":"Aktif sekans yok."}';
        var ti=Number(trackIndex); if(isNaN(ti)||ti<0||ti>=seq.audioTracks.numTracks)ti=0;
        var track=seq.audioTracks[ti], items=track.clips, clips=[];
        for (var ci=0; ci<items.numItems; ci++) {
            var clip=items[ci], selected=false;
            try{selected=clip.isSelected()?true:false}catch(_){}
            if(selectedOnly && !selected)continue;
            var p="";try{if(clip.projectItem)p=clip.projectItem.getMediaPath();}catch(_){}
            if(!p)continue;
            var st=0,en=0,ip=0,op=0,speed=1;
            try{st=Number(clip.start.ticks)/254016000000;}catch(_){}
            try{en=Number(clip.end.ticks)/254016000000;}catch(_){}
            try{ip=Number(clip.inPoint.ticks)/254016000000;}catch(_){}
            try{op=Number(clip.outPoint.ticks)/254016000000;}catch(_){}
            try{speed=Math.abs(Number(clip.getSpeed()));if(!speed)speed=1;}catch(_){speed=1;}
            clips.push('{"track":'+ti+',"selected":'+(selected?'true':'false')+',"name":"'+$._AUTOCUT.esc(clip.name)+'","path":"'+$._AUTOCUT.esc(p)+'","start":'+st+',"end":'+en+',"inPoint":'+ip+',"outPoint":'+op+',"speed":'+speed+'}');
        }
        return '{"ok":true,"track":'+ti+',"clips":['+clips.join(",")+']}';
    } catch(e) {
        return '{"ok":false,"message":"'+$._AUTOCUT.esc(e.toString())+'"}';
    }
};


$._AUTOCUT.applyCuts = function (cutsJson, makeBackup) {
    function esc(x){return $._AUTOCUT.esc(x);}
    function resultItem(c,status,reason){
        return '{"start":'+Number(c.start)+',"end":'+Number(c.end)+',"status":"'+status+'","reason":"'+esc(reason||"")+'"}';
    }
    try {
        var seq=app.project.activeSequence;
        if(!seq)return '{"ok":false,"message":"Aktif sekans yok."}';
        var cuts=eval(cutsJson);
        if(!cuts||!cuts.length)return '{"ok":false,"message":"Uygulanacak kesim yok."}';

        var beforeDur=0;
        try{beforeDur=Number(seq.end)/254016000000;}catch(_){}
        app.enableQE();
        var qseq=qe.project.getActiveSequence();
        if(!qseq)return '{"ok":false,"message":"QE aktif sekansa erişemedi."}';

        cuts.sort(function(x,y){return Number(y.start)-Number(x.start);});
        var applied=0, details=[], planned=0;

        for(var ci=0;ci<cuts.length;ci++){
            var cut=cuts[ci], a=Number(cut.start), b=Number(cut.end);
            planned += Math.max(0,b-a);
            if(!(b>a)){details.push(resultItem(cut,"failed","Geçersiz zaman aralığı"));continue;}
            try{
                var currentEnd=0;
                try{currentEnd=Number(seq.end)/254016000000;}catch(_){currentEnd=beforeDur;}
                var endCut = Math.abs(b-currentEnd)<0.08 || b>=currentEnd-0.02;

                // Razor start always. Razor end only when it is genuinely inside the sequence.
                seq.setPlayerPosition(String(Math.round(a*254016000000)));
                var tcA=qseq.CTI.timecode;
                var tcB=null;
                if(!endCut){
                    seq.setPlayerPosition(String(Math.round(b*254016000000)));
                    tcB=qseq.CTI.timecode;
                }

                var i,vt,at;
                for(i=0;i<qseq.numVideoTracks;i++){
                    vt=qseq.getVideoTrackAt(i);
                    try{vt.razor(tcA);if(tcB)vt.razor(tcB);}catch(_){}
                }
                for(i=0;i<qseq.numAudioTracks;i++){
                    at=qseq.getAudioTrackAt(i);
                    try{at.razor(tcA);if(tcB)at.razor(tcB);}catch(_){}
                }

                var victims=[],tr,clips,j,st,en;
                for(i=0;i<seq.videoTracks.numTracks;i++){
                    tr=seq.videoTracks[i];clips=tr.clips;
                    for(j=0;j<clips.numItems;j++){
                        st=clips[j].start.seconds;en=clips[j].end.seconds;
                        if(st>=a-.003 && (endCut ? en<=currentEnd+.01 : en<=b+.003))victims.push(clips[j]);
                    }
                }
                for(i=0;i<seq.audioTracks.numTracks;i++){
                    tr=seq.audioTracks[i];clips=tr.clips;
                    for(j=0;j<clips.numItems;j++){
                        st=clips[j].start.seconds;en=clips[j].end.seconds;
                        if(st>=a-.003 && (endCut ? en<=currentEnd+.01 : en<=b+.003))victims.push(clips[j]);
                    }
                }
                if(!victims.length){details.push(resultItem(cut,"failed",endCut?"Sekans sonundaki parça bulunamadı":"Kesilen TrackItem bulunamadı"));continue;}

                // Delete all synchronized pieces without ripple, then ripple exactly once.
                for(j=0;j<victims.length-1;j++){try{victims[j].remove(0,1);}catch(_){}}
                var rippled=false;
                try{victims[victims.length-1].remove(1,1);rippled=true;}
                catch(e){try{victims[victims.length-1].remove(0,1);}catch(_){}}
                applied++;
                details.push(resultItem(cut,"applied",endCut?"Sekans sonu özel işlendi":(rippled?"Ripple uygulandı":"Parça kaldırıldı")));
            }catch(e){
                details.push(resultItem(cut,"failed",e.toString()));
            }
        }

        var afterDur=0;
        try{afterDur=Number(seq.end)/254016000000;}catch(_){}
        var actual=Math.max(0,beforeDur-afterDur);
        return '{"ok":true,"applied":'+applied+',"failed":'+(cuts.length-applied)+
          ',"planned":'+planned+',"beforeDuration":'+beforeDur+',"afterDuration":'+afterDur+
          ',"actualRemoved":'+actual+',"details":['+details.join(",")+']}';
    } catch(e) {
        return '{"ok":false,"message":"'+esc(e.toString())+'"}';
    }
};
$._AUTOCUT.applyProbe = function(stage, startSec, endSec) {
    function out(ok, step, msg, extra) {
        return '{"ok":'+(ok?'true':'false')+',"step":"'+$._AUTOCUT.esc(step)+'","message":"'+$._AUTOCUT.esc(msg)+'"'+(extra?','+extra:'')+'}';
    }
    try {
        var seq=app.project.activeSequence;
        if(!seq)return out(false,"sequence","Aktif sekans yok.");
        if(stage==="sequence")return out(true,"sequence","Aktif sekans bulundu: "+seq.name);
        if(stage==="backup"){
            var c=false; try{c=seq.clone()?true:false;}catch(e){return out(false,"backup",e.toString());}
            return out(true,"backup",c?"Sekans yedeği oluşturuldu.":"clone() false döndürdü.");
        }
        if(stage==="qe"){
            try{app.enableQE();var qs=qe.project.getActiveSequence();if(!qs)return out(false,"qe","QE aktif sekans döndürmedi.");}
            catch(e){return out(false,"qe",e.toString());}
            return out(true,"qe","QE aktif.");
        }
        if(stage==="razor"){
            app.enableQE();var qseq=qe.project.getActiveSequence();
            if(!qseq)return out(false,"razor","QE sequence yok.");
            var a=Number(startSec),b=Number(endSec);
            try{
                seq.setPlayerPosition(String(Math.round(a*254016000000)));
                var tcA=qseq.CTI.timecode;
                seq.setPlayerPosition(String(Math.round(b*254016000000)));
                var tcB=qseq.CTI.timecode;
                return out(true,"razor","Timecode üretildi.","\"tcA\":\""+$._AUTOCUT.esc(tcA)+"\",\"tcB\":\""+$._AUTOCUT.esc(tcB)+"\"");
            }catch(e){return out(false,"razor",e.toString());}
        }
        return out(false,"unknown","Bilinmeyen probe.");
    }catch(e){return out(false,stage,e.toString());}
};

function KRALI_pingSequence() {
    try {
        if (!app.project || !app.project.activeSequence) return "ERR|Aktif sekans yok";
        return "OK|" + app.project.activeSequence.name;
    } catch(e) { return "ERR|" + e.toString(); }
}
function KRALI_makeBackup() {
    try {
        var seq=app.project.activeSequence;
        if(!seq)return "ERR|Aktif sekans yok";
        var original=seq.name;
        var ok=seq.clone();
        if(!ok)return "ERR|Sekans kopyalanamadı";
        var cloned=app.project.activeSequence;
        if(cloned && cloned.name!==original){
            try{cloned.name="KRALI - "+original;}catch(_){}
        } else if(cloned) {
            try{cloned.name="KRALI - "+original;}catch(_){}
        }
        return "OK|KRALI - "+original;
    }catch(e){return "ERR|"+e.toString();}
}
