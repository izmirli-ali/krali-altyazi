/* Shell only: the working v3.2 Silence Cut application lives in its own iframe. */
(function(){
 function build(){
  if(document.getElementById("kraliSilenceMenu"))return;
  var header=document.querySelector("body>header"),menu=document.createElement("nav");
  menu.id="kraliSilenceMenu";menu.innerHTML='<button data-mode="subtitle" class="on">ALTYAZI</button><button data-mode="silence">SESSİZLİK KES</button>';
  header.parentNode.insertBefore(menu,header.nextSibling);
  var view=document.createElement("section");view.id="kraliSilenceView";view.hidden=true;
  view.innerHTML='<iframe id="kraliSilenceFrame" title="KRALI Sessizlik Kes" src="modules/silence-cut/index.html"></iframe>';
  document.querySelector("main").parentNode.insertBefore(view,document.querySelector("main"));
  function switchTo(mode){
   var silence=mode==="silence";view.hidden=!silence;
   [".setup",".k26-sectionTitle","main","footer"].forEach(function(s){var x=document.querySelector(s);if(x)x.hidden=silence});
   [].slice.call(menu.querySelectorAll("button")).forEach(function(b){b.classList.toggle("on",b.dataset.mode===mode)});
  }
  [].slice.call(menu.querySelectorAll("button")).forEach(function(b){b.onclick=function(){switchTo(b.dataset.mode)}});
 }
 if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",build);else build();
})();
