KRALI ALTYAZI v6.6.2 OTA FINAL
- GÖRÜNÜM ana dört satırı tekrar çalıştırmalarda kontrolleri silmeyen idempotent authoritative DOM container olarak kurulur.
- Input ID'leri taşınır; mevcut renderer/event bağlantıları korunur.
- Ana satırlarda slider yoktur.
- GELİŞMİŞ alanına dokunulmaz.
- Updater disabled manifest durumunda artık 'Güncel' mesajına geçer.
- OTA updater version: 6.6.2.
