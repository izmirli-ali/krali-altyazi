const cs=new CSInterface();
const HOST_JSX_VERSION="3.2.0";
const fs=require("fs"),path=require("path"),os=require("os"),cp=require("child_process");
const $=id=>document.getElementById(id),TICKS=254016000000;
let LAST_RESULT=null,SELECTED_CUT=-1,PLAYHEAD_TIME=null,PLAYHEAD_TIMER=null,PREVIEW_AUDIO=null,PREVIEW_URL=null;
let SEQ_INFO={name:"",duration:0},MEDIA_CACHE=new Map(),ANALYSIS_CONTEXT=null;

function jsxPath(){try{return cs.getSystemPath(SystemPath.EXTENSION)+"/jsx/host.jsx"}catch(e){return null}}
function loadHostJSX(){return new Promise((resolve,reject)=>{const p=jsxPath();if(!p)return reject(Error("Extension yolu alınamadı."));const e=p.replace(/\\/g,"\\\\").replace(/"/g,'\\"');cs.evalScript('$.evalFile("'+e+'")',r=>{if(r==="EvalScript error.")return reject(Error("host.jsx yüklenemedi."));cs.evalScript('$._AUTOCUT&&$._AUTOCUT.hostVersion?$._AUTOCUT.hostVersion():"NO_HOST_VERSION"',v=>v==="EvalScript error."||v==="NO_HOST_VERSION"?reject(Error("Host Engine doğrulanamadı: "+v)):resolve(v))})})}
function evalHost(code){return new Promise((resolve,reject)=>cs.evalScript(code,r=>r==="EvalScript error."?reject(Error(r)):resolve(r)))}
function safeJSON(s){try{return JSON.parse(s)}catch(e){throw Error("Host returned invalid data: "+s)}}
function setMsg(t){$("msg").textContent=t}function state(t){$("state").textContent=t}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}function db(v){return 20*Math.log10(Math.max(v,1e-9))}
function formatTime(sec){sec=Math.max(0,+sec||0);const m=Math.floor(sec/60),ss=sec-m*60;return String(m).padStart(2,"0")+":"+ss.toFixed(2).padStart(5,"0")}
function activeStyle(){const x=[...document.querySelectorAll(".styleBtn")].find(b=>b.classList.contains("active"));return x?x.textContent.trim():"Dengeli"}
function sequenceDuration(){return SEQ_INFO.duration||60}

async function refresh(){
 try{
  const q=safeJSON(await evalHost("$._AUTOCUT.getSequenceInfo()"));if(!q.ok)throw Error(q.message);SEQ_INFO=q;
  $("seq").textContent=q.name+" · "+formatTime(q.duration);
  const t=safeJSON(await evalHost("$._AUTOCUT.getAudioTracks()"));if(t.ok){
   const old=$("trackSelect").value;$("trackSelect").innerHTML=t.tracks.map(x=>`<option value="${x.index}">${x.label} · ${x.clips} klip</option>`).join("");
   if([...$("trackSelect").options].some(o=>o.value===old))$("trackSelect").value=old;
  }
  invalidateContext("Sequence/track bilgisi yenilendi.");
 }catch(e){state("ERROR");setMsg("Sequence: "+e.message);$("seq").textContent="Premiere bağlantı hatası"}
}
function invalidateContext(msg){ANALYSIS_CONTEXT=null;LAST_RESULT=null;SELECTED_CUT=-1;$("cacheState").textContent="○ Analiz bekleniyor";$("cacheState").classList.remove("ready");$("applyBtn").disabled=true;if(msg)setMsg(msg)}

function decodeMacToWav(input){
 return new Promise((resolve,reject)=>{
  if(process.platform!=="darwin")return reject(Error("Yerel decoder şu an macOS gerektiriyor."));
  if(!fs.existsSync("/usr/bin/afconvert"))return reject(Error("macOS afconvert bulunamadı."));
  const out=path.join(os.tmpdir(),"krali31_"+Date.now()+"_"+Math.random().toString(16).slice(2)+".wav");
  cp.execFile("/usr/bin/afconvert",[input,out,"-f","WAVE","-d","LEI16@16000","-c","1"],{timeout:120000},(err,stdout,stderr)=>{
   if(err){try{fs.unlinkSync(out)}catch(_){}return reject(Error("Core Audio decode: "+String(stderr||err.message).trim()))}
   if(!fs.existsSync(out)||fs.statSync(out).size<=44)return reject(Error("Geçerli WAV üretilemedi."));resolve(out)
  })
 })
}
function parseWav(file){
 const b=fs.readFileSync(file);if(b.toString("ascii",0,4)!=="RIFF"||b.toString("ascii",8,12)!=="WAVE")throw Error("PCM WAV okunamadı.");
 let pos=12,fmt=null,dataOff=0,dataSize=0;
 while(pos+8<=b.length){const id=b.toString("ascii",pos,pos+4),n=b.readUInt32LE(pos+4),o=pos+8;if(id==="fmt ")fmt={format:b.readUInt16LE(o),channels:b.readUInt16LE(o+2),rate:b.readUInt32LE(o+4),bits:b.readUInt16LE(o+14)};if(id==="data"){dataOff=o;dataSize=n;break}pos=o+n+(n%2)}
 if(!fmt||!dataOff||fmt.format!==1)throw Error("Desteklenmeyen WAV.");const bytes=fmt.bits/8,total=Math.floor(dataSize/(bytes*fmt.channels)),frameSamples=Math.max(1,Math.round(fmt.rate*.02)),frames=[];
 for(let si=0;si<total;si+=frameSamples){let ee=Math.min(total,si+frameSamples),sum=0,c=0;for(let i=si;i<ee;i++)for(let ch=0;ch<fmt.channels;ch++){let o=dataOff+(i*fmt.channels+ch)*bytes,v=0;if(fmt.bits===16)v=b.readInt16LE(o)/32768;else if(fmt.bits===24)v=b.readIntLE(o,3)/8388608;else if(fmt.bits===32)v=b.readInt32LE(o)/2147483648;else throw Error("WAV bit depth: "+fmt.bits);sum+=v*v;c++}frames.push(db(Math.sqrt(sum/Math.max(1,c))))}
 return {frames,rate:fmt.rate,duration:total/fmt.rate,step:.02}
}
async function mediaData(p){
 const st=fs.statSync(p),key=p+"|"+st.size+"|"+Math.floor(st.mtimeMs);if(MEDIA_CACHE.has(key))return MEDIA_CACHE.get(key);
 let wav=p,temp=false;if(!/\.wav$/i.test(p)){wav=await decodeMacToWav(p);temp=true}
 const parsed=parseWav(wav),obj={key,path:p,wav,temp,...parsed};MEDIA_CACHE.set(key,obj);return obj
}
function profile(){const s=activeStyle();return s==="Doğal"?{min:.58,pad:.16,margin:9,bridge:.06}:s==="Agresif"?{min:.30,pad:.07,margin:14,bridge:.18}:{min:.42,pad:.12,margin:11.5,bridge:.10}}
// Speech-edge protection: keep low-energy consonant tails / word attacks out of the cut.
// It does not try to understand language or sentences; it only refines silence boundaries
// from the local energy shape, so it remains generic across videos/languages.
function protectSpeechEdges(frames, rawStart, rawEnd, enter, exit, step, speed){
 const pf=profile();
 const guardSec=activeStyle()==="Doğal"?.16:activeStyle()==="Agresif"?.08:.12;
 const guard=Math.max(2,Math.round(guardSec*speed/step));
 const rise=Math.max(1.5, activeStyle()==="Agresif"?2.0:2.5);
 let a=rawStart,b=rawEnd;
 // At the left boundary, walk right while the signal is still decaying / unstable.
 let limit=Math.min(rawEnd-1,rawStart+guard),prev=frames[Math.max(0,rawStart-1)]||enter;
 for(let i=rawStart;i<=limit;i++){
   const v=frames[i],next=frames[Math.min(frames.length-1,i+1)];
   if(v>enter-2 || Math.abs(v-prev)>rise || Math.abs(next-v)>rise){a=i+1;prev=v;continue}
   break
 }
 // At the right boundary, walk left while speech-like attack/transition is visible.
 limit=Math.max(a+1,rawEnd-guard);prev=frames[Math.min(frames.length-1,rawEnd)]||enter;
 for(let i=rawEnd-1;i>=limit;i--){
   const v=frames[i],pr=frames[Math.max(0,i-1)];
   if(v>enter-2 || Math.abs(prev-v)>rise || Math.abs(v-pr)>rise){b=i;prev=v;continue}
   break
 }
 // Extra micro-guard in source time. This is deliberately small and style-aware.
 const micro=Math.round((activeStyle()==="Doğal"?.035:activeStyle()==="Agresif"?.018:.025)*speed/step);
 a=Math.min(b-1,a+micro); b=Math.max(a+1,b-micro);
 return [a,b];
}
function gateClip(media,clip){
 const step=media.step,speed=Math.max(.01,clip.speed||1),sourceStart=Math.max(0,clip.inPoint||0),sourceEnd=Math.min(media.duration,clip.outPoint>sourceStart?clip.outPoint:sourceStart+(clip.end-clip.start)*speed);
 const i0=Math.max(0,Math.floor(sourceStart/step)),i1=Math.min(media.frames.length,Math.ceil(sourceEnd/step)),frames=media.frames.slice(i0,i1);
 if(!frames.length)return {cuts:[],threshold:-30,envelope:[]};
 const sorted=frames.slice().sort((a,b)=>a-b),q=p=>sorted[Math.min(sorted.length-1,Math.max(0,Math.floor(sorted.length*p)))]||-60,p10=q(.1),p25=q(.25),p75=q(.75),floor=(p10+p25)/2,pf=profile();
 let enter=clamp(floor+pf.margin,-50,-24),exit=clamp(enter+3.5,-46,-20);
 if(!$("autoDb").checked){enter=+$("dbRange").value;exit=Math.min(-10,enter+3.5)}
 if(p75-p25<10){enter=Math.max(enter,Math.min(-27,p25+7));exit=Math.max(exit,enter+3)}
 const minFrames=Math.max(1,Math.round(pf.min*speed/step));let raw=[],run=-1,quiet=false,release=0;
 for(let i=0;i<frames.length;i++){const v=frames[i];if(!quiet){if(v<enter){if(run<0)run=i;if(i-run+1>=3)quiet=true}else run=-1}else{if(v>exit){release++;if(release>=3){const e=i-release+1;if(run>=0&&e-run>=minFrames)raw.push([run,e]);quiet=false;run=-1;release=0}}else release=0}}
 if(quiet&&run>=0&&frames.length-run>=minFrames)raw.push([run,frames.length]);
 // Tiny speech islands become one edit candidate instead of two micro-cuts.
 const bridgeFrames=Math.round(pf.bridge*speed/step),merged=[];for(const r of raw){const last=merged[merged.length-1];if(last&&r[0]-last[1]<=bridgeFrames)last[1]=r[1];else merged.push(r.slice())}
 const pad=+$("paddingRange").value,cuts=[];
 for(const r of merged){
   const edge=protectSpeechEdges(frames,r[0],r[1],enter,exit,step,speed);
   const srcA=sourceStart+edge[0]*step,srcB=sourceStart+edge[1]*step;
   let a=clip.start+(srcA-sourceStart)/speed+pad,z=clip.start+(srcB-sourceStart)/speed-pad;
   a=Math.max(clip.start,a);z=Math.min(clip.end,z);
   if(z>a&&z-a>=.04)cuts.push({start:a,end:z,duration:z-a,clipRef:clip,edgeProtected:true})
 }
 const envelope=[];const bucket=Math.max(1,Math.floor(frames.length/300));for(let i=0;i<frames.length;i+=bucket){let mx=-100;for(let j=i;j<Math.min(frames.length,i+bucket);j++)mx=Math.max(mx,frames[j]);envelope.push(mx)}
 return {cuts,threshold:enter,envelope}
}
function recompute(){
 if(!ANALYSIS_CONTEXT)return;
 let cuts=[],ths=[];for(const x of ANALYSIS_CONTEXT.items){const r=gateClip(x.media,x.clip);cuts.push(...r.cuts);ths.push(r.threshold)}
 cuts.sort((a,b)=>a.start-b.start);
 // Deduplicate/merge overlapping candidates produced by edits/repeated sources.
 const merged=[];for(const c of cuts){const last=merged[merged.length-1];if(last&&c.start<=last.end+.015){last.end=Math.max(last.end,c.end);last.duration=last.end-last.start}else merged.push(c)}
 const env=buildTimelineEnvelope(ANALYSIS_CONTEXT.items);
 renderResult({cuts:merged,threshold:ths.length?ths.reduce((a,b)=>a+b,0)/ths.length:-30,envelope:env});
 $("cacheState").textContent="● Ses analizi hazır";$("cacheState").classList.add("ready");setMsg(`${activeStyle()} · ${merged.length} kesim · konuşma kenarları korunuyor · cache hazır.`)
}
function buildTimelineEnvelope(items){
 const n=600,d=sequenceDuration(),env=new Array(n).fill(-100);
 for(const x of items){const c=x.clip,m=x.media,speed=Math.max(.01,c.speed||1),ss=Math.max(0,c.inPoint||0),se=Math.min(m.duration,c.outPoint>ss?c.outPoint:ss+(c.end-c.start)*speed),i0=Math.floor(ss/m.step),i1=Math.min(m.frames.length,Math.ceil(se/m.step));
  for(let i=i0;i<i1;i++){const src=ss+(i-i0)*m.step,t=c.start+(src-ss)/speed,bi=Math.floor(t/d*n);if(bi>=0&&bi<n)env[bi]=Math.max(env[bi],m.frames[i])}
 }return env
}
async function analyze(){
 try{
  state("SOURCE");setMsg("Seçilen track okunuyor…");const track=+$("trackSelect").value,selected=$("scopeSelect").value==="selected";
  const m=safeJSON(await evalHost(`$._AUTOCUT.getSourceMedia(${track},${selected?"true":"false"})`));if(!m.ok)throw Error(m.message);if(!m.clips.length)throw Error(selected?"Seçili ses klibi bulunamadı. Önce A track'inde klip seç.":"Bu track'te dosyaya bağlı ses klibi yok.");
  const items=[],unique=new Map();for(let i=0;i<m.clips.length;i++){const c=m.clips[i];if(!c.path||!fs.existsSync(c.path))continue;state("DECODE");setMsg(`Yerel ses hazırlanıyor… ${i+1}/${m.clips.length}`);let md=unique.get(c.path);if(!md){md=await mediaData(c.path);unique.set(c.path,md)}items.push({clip:c,media:md})}
  if(!items.length)throw Error("Okunabilir medya bulunamadı.");ANALYSIS_CONTEXT={seqName:SEQ_INFO.name,track,selected,items};recompute();state("READY");
  setMsg(`✓ ${items.length} klip · ${unique.size} kaynak hazır. Stil/dB/aralık değişiklikleri artık yeniden decode etmeden hesaplanır.`)
 }catch(e){state("ERROR");setMsg(e.message)}
}

function drawWave(envelope,cuts){const cv=$("wave");if(!cv)return;const zoom=+$("zoomRange").value||1,wrap=cv.parentElement,base=Math.max(240,wrap.clientWidth),w=base*zoom,h=96,dpr=devicePixelRatio||1;cv.style.width=w+"px";cv.width=w*dpr;cv.height=h*dpr;const c=cv.getContext("2d");c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);c.strokeStyle="#909098";c.beginPath();(envelope||[]).forEach((v,i)=>{const amp=clamp((v+60)/60,0,1),x=i/Math.max(1,envelope.length-1)*w,hh=amp*h*.43;c.moveTo(x,h/2-hh);c.lineTo(x,h/2+hh)});c.stroke();const dur=sequenceDuration();(cuts||[]).forEach((k,i)=>{const x=k.start/dur*w,ww=(k.end-k.start)/dur*w;c.fillStyle=k.enabled===false?"rgba(100,100,100,.2)":i===SELECTED_CUT?"rgba(103,88,255,.72)":"rgba(103,88,255,.4)";c.fillRect(x,0,Math.max(3,ww),h)});if(PLAYHEAD_TIME!==null){const px=clamp(PLAYHEAD_TIME/dur,0,1)*w;c.fillStyle="#fff";c.fillRect(px-1,0,2,h)}}
function drawDetail(){const cv=$("detailWave");if(!cv||!LAST_RESULT||SELECTED_CUT<0)return;const k=LAST_RESULT.cuts[SELECTED_CUT],from=Math.max(0,k.start-2.5),to=Math.min(sequenceDuration(),k.end+2.5),w=Math.max(220,cv.getBoundingClientRect().width),h=76,dpr=devicePixelRatio||1;cv.width=w*dpr;cv.height=h*dpr;const c=cv.getContext("2d");c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,w,h);const env=LAST_RESULT.envelope||[],dur=sequenceDuration();c.strokeStyle="#999";c.beginPath();for(let i=0;i<env.length;i++){const t=i/Math.max(1,env.length-1)*dur;if(t<from||t>to)continue;const x=(t-from)/(to-from)*w,hh=clamp((env[i]+60)/60,0,1)*h*.42;c.moveTo(x,h/2-hh);c.lineTo(x,h/2+hh)}c.stroke();const x1=(k.start-from)/(to-from)*w,x2=(k.end-from)/(to-from)*w;c.fillStyle=k.enabled===false?"rgba(100,100,100,.25)":"rgba(103,88,255,.5)";c.fillRect(x1,0,Math.max(3,x2-x1),h);if(PLAYHEAD_TIME!==null&&PLAYHEAD_TIME>=from&&PLAYHEAD_TIME<=to){const px=(PLAYHEAD_TIME-from)/(to-from)*w;c.fillStyle="#fff";c.fillRect(px-1,0,2,h)}cv.dataset.from=from;cv.dataset.to=to;$("detailTime").textContent=`${from.toFixed(2)}–${to.toFixed(2)} sn`}
function selectedCuts(){return LAST_RESULT?LAST_RESULT.cuts.filter(c=>c.enabled!==false):[]}
function refreshSelectedStats(){if(!LAST_RESULT)return;const c=selectedCuts();$("cuts").textContent=c.length;$("removed").textContent=c.reduce((a,x)=>a+x.duration,0).toFixed(2)+" sn";$("applyBtn").disabled=!c.length;$("applyBtn").classList.toggle("ready",!!c.length)}
function renderResult(r){LAST_RESULT=r;r.cuts.forEach(c=>{if(c.enabled===undefined)c.enabled=true});$("threshold").textContent=(+r.threshold).toFixed(1)+" dB";$("plan").innerHTML=r.cuts.length?r.cuts.map((c,i)=>`<div class="planrow ${c.enabled===false?"off":""}" data-i="${i}"><input class="cutcheck" data-i="${i}" type="checkbox" ${c.enabled!==false?"checked":""}><span>${i+1}. ${c.start.toFixed(2)} → ${c.end.toFixed(2)} <small>${c.duration.toFixed(2)} sn</small></span><button class="planplay" data-i="${i}">▶</button></div>`).join(""):"<p>Bu ayarlarda kesim bulunamadı.</p>";document.querySelectorAll(".planrow").forEach(x=>x.onclick=e=>{if(!e.target.matches("input,button"))selectCut(+x.dataset.i)});document.querySelectorAll(".cutcheck").forEach(x=>x.onchange=e=>{const i=+e.target.dataset.i;r.cuts[i].enabled=e.target.checked;e.target.closest(".planrow").classList.toggle("off",!e.target.checked);refreshSelectedStats();drawWave(r.envelope,r.cuts);drawDetail()});document.querySelectorAll(".planplay").forEach(x=>x.onclick=e=>{selectCut(+e.currentTarget.dataset.i);playOriginal()});refreshSelectedStats();drawWave(r.envelope,r.cuts);if(r.cuts.length)selectCut(Math.min(Math.max(0,SELECTED_CUT),r.cuts.length-1))}
function selectCut(i){SELECTED_CUT=i;const k=LAST_RESULT.cuts[i];$("selectionInfo").textContent=`Kesim ${i+1} · ${k.start.toFixed(2)}–${k.end.toFixed(2)} sn`;drawWave(LAST_RESULT.envelope,LAST_RESULT.cuts);drawDetail()}

function previewMapping(t){if(!ANALYSIS_CONTEXT)return null;for(const x of ANALYSIS_CONTEXT.items){const c=x.clip;if(t>=c.start-.001&&t<=c.end+.001){const speed=Math.max(.01,c.speed||1),source=(c.inPoint||0)+(t-c.start)*speed;return {x,source}}}return null}
function stopPreview(){if(PLAYHEAD_TIMER){clearInterval(PLAYHEAD_TIMER);PLAYHEAD_TIMER=null}if(PREVIEW_AUDIO){try{PREVIEW_AUDIO.pause()}catch(_){}PREVIEW_AUDIO=null}if(PREVIEW_URL){try{URL.revokeObjectURL(PREVIEW_URL)}catch(_){}PREVIEW_URL=null}}
function playTimeline(start,skipCut){
 const map=previewMapping(start);if(!map){setMsg("Bu noktada seçilen konuşma track'ine ait önizleme sesi yok.");return}stopPreview();const wav=map.x.media.wav,buf=fs.readFileSync(wav);PREVIEW_URL=URL.createObjectURL(new Blob([buf],{type:"audio/wav"}));PREVIEW_AUDIO=new Audio(PREVIEW_URL);const clip=map.x.clip,speed=Math.max(.01,clip.speed||1),cut=skipCut;
 PREVIEW_AUDIO.onloadedmetadata=()=>{PREVIEW_AUDIO.currentTime=clamp(map.source,0,PREVIEW_AUDIO.duration);PREVIEW_AUDIO.play();PLAYHEAD_TIME=start;PLAYHEAD_TIMER=setInterval(()=>{if(!PREVIEW_AUDIO)return;let timeline=clip.start+(PREVIEW_AUDIO.currentTime-(clip.inPoint||0))/speed;if(cut&&timeline>=cut.start-.015&&timeline<cut.end){PREVIEW_AUDIO.currentTime=(clip.inPoint||0)+(cut.end-clip.start)*speed;timeline=cut.end}PLAYHEAD_TIME=timeline;$("selectionInfo").textContent=(cut?"Kesilmiş önizleme: ":"Oynatma: ")+timeline.toFixed(2)+" sn";drawWave(LAST_RESULT.envelope,LAST_RESULT.cuts);drawDetail();if(cut&&timeline>cut.end+1.0)stopPreview()},50)}
}
function playOriginal(){if(!LAST_RESULT||SELECTED_CUT<0)return;const k=LAST_RESULT.cuts[SELECTED_CUT];playTimeline(Math.max(k.start-.8,0),null)}
function playCutPreview(){if(!LAST_RESULT||SELECTED_CUT<0)return;const k=LAST_RESULT.cuts[SELECTED_CUT];playTimeline(Math.max(k.start-.8,0),k)}

async function applyCuts(){
 if(!LAST_RESULT||!selectedCuts().length){setMsg("Önce analiz yap ve en az bir kesim seç.");return}const chosen=selectedCuts(),first=chosen[0],diag=$("applyDiag"),log=[],show=x=>{log.push(x);diag.textContent=log.join("\n");diag.classList.add("show")};
 try{state("TEST");$("applyBtn").disabled=true;show("1/6 · Host Engine…");const hv=await loadHostJSX();show("✓ v"+hv);show("2/6 · Sequence…");let raw=await evalHost("$._AUTOCUT.pingSequence()");if(raw.indexOf("ERR|")===0)throw Error(raw);show("✓ "+raw.slice(3));show("3/6 · Güvenli kopya…");raw=await evalHost("$._AUTOCUT.makeBackup()");if(raw.indexOf("ERR|")===0)throw Error(raw);show("✓ "+raw.slice(3));show("4/6 · QE…");let r=safeJSON(await evalHost('$._AUTOCUT.applyProbe("qe",0,0)'));if(!r.ok)throw Error(r.message);show("✓ QE aktif");show("5/6 · Timecode…");r=safeJSON(await evalHost(`$._AUTOCUT.applyProbe("razor",${+first.start},${+first.end})`));if(!r.ok)throw Error(r.message);show("✓ hazır");show("6/6 · Kesimler…");const payload=JSON.stringify(chosen.map(c=>({start:c.start,end:c.end})));r=safeJSON(await evalHost('$._AUTOCUT.applyCuts('+JSON.stringify(payload)+',false)'));if(!r.ok)throw Error(r.message);show(`✓ ${r.applied}/${chosen.length}`);(r.details||[]).forEach(d=>show(`${d.status==="applied"?"✓":"✕"} ${d.start.toFixed(2)}→${d.end.toFixed(2)} · ${d.reason}`));show(`Plan ${(+r.planned).toFixed(2)} sn · Gerçek ${(+r.actualRemoved).toFixed(2)} sn`);diag.classList.remove("show");setMsg(`✓ ${r.applied}/${chosen.length} kesim · ${(+r.actualRemoved).toFixed(2)} sn kaldırıldı · ${raw.slice(3)}`);state("READY");LAST_RESULT=null;ANALYSIS_CONTEXT=null;$("applyBtn").disabled=true;setTimeout(refresh,400)}
 catch(e){state("ERROR");show("✕ "+e.message);setMsg("Kesim motoru: "+e.message);$("applyBtn").disabled=false}
}

function liveRecompute(){if(ANALYSIS_CONTEXT){recompute();state("READY")}}
document.addEventListener("DOMContentLoaded",()=>{
 $("applyBtn").disabled=true;loadHostJSX().then(v=>{$("hostStatus").textContent="v"+v+" ✓";state("READY");refresh()}).catch(e=>{$("hostStatus").textContent="HOST HATA";setMsg(e.message)});
 $("refreshBtn").onclick=refresh;$("reloadBtn").onclick=()=>location.reload();$("analyzeBtn").onclick=analyze;$("applyBtn").onclick=applyCuts;$("playPreview").onclick=playOriginal;$("playCutPreview").onclick=playCutPreview;$("stopPreview").onclick=stopPreview;
 document.querySelectorAll(".styleBtn").forEach(b=>b.onclick=()=>{document.querySelectorAll(".styleBtn").forEach(x=>x.classList.remove("active"));b.classList.add("active");const p=profile();$("minSilence").value=p.min;$("paddingRange").value=p.pad;$("paddingOut").textContent=p.pad.toFixed(2)+" sn";$("before").value=p.pad;$("after").value=p.pad;liveRecompute()});
 $("paddingRange").oninput=()=>{const v=+$("paddingRange").value;$("paddingOut").textContent=v.toFixed(2)+" sn";$("before").value=v;$("after").value=v;liveRecompute()};
 $("autoDb").onchange=()=>{$("dbRange").disabled=$("autoDb").checked;$("dbOut").textContent=$("autoDb").checked?"AUTO":$("dbRange").value+" dB";liveRecompute()};$("dbRange").oninput=()=>{$("dbOut").textContent=$("dbRange").value+" dB";liveRecompute()};
 $("trackSelect").onchange=()=>invalidateContext("Track değişti. Yeni track için ANALİZ ET.");$("scopeSelect").onchange=()=>invalidateContext("Analiz alanı değişti. ANALİZ ET.");
 $("zoomRange").oninput=()=>{$("zoomOut").textContent=$("zoomRange").value+"×";if(LAST_RESULT)drawWave(LAST_RESULT.envelope,LAST_RESULT.cuts)};
 $("diagToggle").onclick=()=>$("applyDiag").classList.toggle("show");
 $("detailWave").onclick=e=>{if(!LAST_RESULT)return;const cv=$("detailWave"),r=cv.getBoundingClientRect(),from=+cv.dataset.from||0,to=+cv.dataset.to||sequenceDuration(),t=from+clamp((e.clientX-r.left)/r.width,0,1)*(to-from);PLAYHEAD_TIME=t;playTimeline(t,null)};
 $("wave").onclick=e=>{if(!LAST_RESULT)return;const r=$("wave").getBoundingClientRect(),t=clamp((e.clientX-r.left)/r.width*sequenceDuration(),0,sequenceDuration());let best=-1,d=1e9;LAST_RESULT.cuts.forEach((k,i)=>{const dd=t>=k.start&&t<=k.end?0:Math.min(Math.abs(t-k.start),Math.abs(t-k.end));if(dd<d){d=dd;best=i}});if(best>=0)selectCut(best);playTimeline(t,null)};
});
